import tkinter as tk
from tkinter import ttk
from app.win_home import open_win_home
from app.win_form import open_win_form
from app.win_list import open_win_list
from app.win_table import open_win_table
from app.win_canvas import open_win_canvas

def configurar_estilo():
    style = ttk.Style()
    style.theme_use("clam")  # base moderna y simple

    # Colores principales
    color_fondo = "#f5f7fa"
    color_boton = "#0078d7"
    color_texto = "#222"
    color_hover = "#005fa3"

    # Fondo general
    style.configure(".", background=color_fondo, foreground=color_texto, font=("Segoe UI", 10))

    # Botones
    style.configure("TButton",
                    background=color_boton,
                    foreground="white",
                    borderwidth=0,
                    padding=6)
    style.map("TButton",
              background=[("active", color_hover)],
              relief=[("pressed", "sunken")])

    # Label y Frame
    style.configure("TLabel", background=color_fondo, foreground=color_texto)
    style.configure("TFrame", background=color_fondo)

def main():
    root = tk.Tk()
    root.title("UniBudget")
    root.geometry("480x420")

    configurar_estilo()

    frm = ttk.Frame(root, padding=20)
    frm.pack(fill="both", expand=True)

    ttk.Label(frm, text="🏦 UniBudget", font=("Segoe UI", 13, "bold")).pack(pady=(0, 10))
    ttk.Separator(frm, orient="horizontal").pack(fill="x", pady=8)

    ttk.Button(frm, text="🏠 Inicio / Dashboard", command=lambda: open_win_home(root)).pack(fill="x", pady=4)
    ttk.Button(frm, text="➕ Registrar Movimiento", command=lambda: open_win_form(root)).pack(fill="x", pady=4)
    ttk.Button(frm, text="📋 Tabla de Movimientos", command=lambda: open_win_table(root)).pack(fill="x", pady=4)
    ttk.Button(frm, text="📑 Metas de ahorro", command=lambda: open_win_list(root)).pack(fill="x", pady=4)
    ttk.Button(frm, text="📈 Inflación", command=lambda: open_win_canvas(root)).pack(fill="x", pady=4)

    ttk.Separator(frm, orient="horizontal").pack(fill="x", pady=8)
    ttk.Button(frm, text="Salir", command=root.destroy).pack(pady=(10, 4))

    root.mainloop()

if __name__ == "__main__":
    main()
