import tkinter as tk
from tkinter import ttk, messagebox
import requests
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

def open_win_canvas(parent: tk.Tk):
    win = tk.Toplevel(parent)
    win.title("📈 Inflación en México (Banco Mundial)")
    win.geometry("720x550")
    win.configure(bg="#f5f7fa")

    frm = ttk.Frame(win, padding=16)
    frm.pack(fill="both", expand=True)

    ttk.Label(frm, text="Inflación Anual - México", font=("Segoe UI", 12, "bold")).pack(pady=(0, 8))
    ttk.Separator(frm, orient="horizontal").pack(fill="x", pady=6)

    ttk.Label(frm, text="Datos obtenidos de la API del Banco Mundial", font=("Segoe UI", 9, "italic"), foreground="gray").pack(pady=(0, 12))

    # --- Función para obtener los datos de la API ---
    def obtener_datos_inflacion():
        try:
            url = "https://api.worldbank.org/v2/country/MX/indicator/FP.CPI.TOTL.ZG?format=json"
            response = requests.get(url, timeout=10)
            response.raise_for_status()

            data = response.json()
            registros = data[1]  # la información está en el índice 1

            # Filtrar los últimos 10 años con datos válidos
            datos_filtrados = [
                (int(item["date"]), float(item["value"]))
                for item in registros
                if item["value"] is not None
            ][:10]

            if not datos_filtrados:
                messagebox.showerror("Error", "No se encontraron datos de inflación.")
                return [], []

            # Invertir el orden para que los años estén ascendentes
            datos_filtrados.reverse()

            años = [a for a, _ in datos_filtrados]
            valores = [v for _, v in datos_filtrados]

            return años, valores

        except Exception as e:
            messagebox.showerror("Error al obtener datos", str(e))
            return [], []

    # --- Función para graficar los datos ---
    def graficar():
        años, valores = obtener_datos_inflacion()
        if not años:
            return

        fig, ax = plt.subplots(figsize=(6, 3.5))
        ax.plot(años, valores, marker="o", color="#0078d7", linewidth=2)
        ax.set_title("Inflación anual en México (últimos 10 años)", fontsize=11, weight="bold")
        ax.set_xlabel("Año")
        ax.set_ylabel("Inflación (%)")
        ax.grid(True, linestyle="--", alpha=0.5)

        # Mostrar el gráfico dentro de Tkinter
        for widget in frm.winfo_children():
            if isinstance(widget, FigureCanvasTkAgg):
                widget.get_tk_widget().destroy()

        canvas = FigureCanvasTkAgg(fig, master=frm)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, pady=(10, 0))

    # --- Botones ---
    frm_botones = ttk.Frame(win, padding=10)
    frm_botones.pack(fill="x", side="bottom")

    ttk.Button(frm_botones, text="Actualizar", command=graficar).pack(side="left", padx=6)
    ttk.Button(frm_botones, text="Cerrar", command=win.destroy).pack(side="right", padx=6)

    # Graficar automáticamente al abrir
    graficar()

    win.transient(parent)
    win.grab_set()
    parent.wait_window(win)
