import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import csv
from pathlib import Path

def open_win_form(parent: tk.Tk):
    win = tk.Toplevel(parent)
    win.title("➕ Registrar Movimiento")
    win.geometry("460x380")
    win.configure(bg="#f5f7fa")

    frm = ttk.Frame(win, padding=16)
    frm.pack(fill="both", expand=True)

    ttk.Label(frm, text="Tipo de movimiento:", font=("Segoe UI", 10)).grid(row=0, column=0, sticky="w", pady=4)
    tipo_var = tk.StringVar(value="Ingreso")
    cmb_tipo = ttk.Combobox(frm, textvariable=tipo_var, values=["Ingreso", "Gasto"], state="readonly", width=20)
    cmb_tipo.grid(row=0, column=1, pady=4, sticky="w")

    ttk.Label(frm, text="Monto:", font=("Segoe UI", 10)).grid(row=1, column=0, sticky="w", pady=4)
    ent_monto = ttk.Entry(frm, width=22)
    ent_monto.grid(row=1, column=1, pady=4, sticky="w")

    ttk.Label(frm, text="Categoría:", font=("Segoe UI", 10)).grid(row=2, column=0, sticky="w", pady=4)
    cmb_categoria = ttk.Combobox(frm, values=["Alimentos", "Transporte", "Salud", "Ocio", "Sueldo", "Otro"], width=18)
    cmb_categoria.grid(row=2, column=1, pady=4, sticky="w")

    ttk.Label(frm, text="Fecha:", font=("Segoe UI", 10)).grid(row=3, column=0, sticky="w", pady=4)
    ent_fecha = ttk.Entry(frm, width=22)
    ent_fecha.grid(row=3, column=1, pady=4, sticky="w")
    ent_fecha.insert(0, datetime.now().strftime("%Y-%m-%d"))

    ttk.Label(frm, text="Descripción:", font=("Segoe UI", 10)).grid(row=4, column=0, sticky="nw", pady=4)
    txt_desc = tk.Text(frm, width=30, height=4, font=("Segoe UI", 9))
    txt_desc.grid(row=4, column=1, pady=4, sticky="w")

    # Ruta del archivo
    data_dir = Path(__file__).resolve().parents[2] / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    data_path = data_dir / "sample.csv"

    def guardar_datos():
        tipo = tipo_var.get()
        monto = ent_monto.get().strip()
        categoria = cmb_categoria.get().strip() or "Sin categoría"
        fecha = ent_fecha.get().strip()
        descripcion = txt_desc.get("1.0", "end").strip()

        if not monto.replace(".", "", 1).isdigit():
            messagebox.showerror("Error", "El monto debe ser un número.")
            return
        try:
            datetime.strptime(fecha, "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Error", "Formato de fecha inválido (usa YYYY-MM-DD).")
            return

        nuevo = [tipo, monto, categoria, fecha, descripcion]
        encabezado = ["Tipo", "Monto", "Categoría", "Fecha", "Descripción"]

        nuevo_archivo = not data_path.exists()
        with open(data_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            if nuevo_archivo:
                writer.writerow(encabezado)
            writer.writerow(nuevo)

        messagebox.showinfo("✅ Éxito", "Movimiento guardado correctamente.")
        ent_monto.delete(0, "end")
        txt_desc.delete("1.0", "end")

    # Botones
    ttk.Separator(frm, orient="horizontal").grid(row=5, columnspan=2, sticky="ew", pady=8)
    ttk.Button(frm, text="Guardar", command=guardar_datos).grid(row=6, column=0, pady=8)
    ttk.Button(frm, text="Cerrar", command=win.destroy).grid(row=6, column=1, sticky="e", pady=8)

    win.transient(parent)
    win.grab_set()
    parent.wait_window(win)
