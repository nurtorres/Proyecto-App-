import tkinter as tk
from tkinter import ttk, messagebox
import csv
from pathlib import Path
from app.win_form import open_win_form
from app.win_table import open_win_table
from app.win_list import open_win_list

def open_win_home(parent: tk.Tk):
    win = tk.Toplevel(parent)
    win.title("Panel Principal - Finanzas Personales")
    win.geometry("480x400")

    frm = ttk.Frame(win, padding=16)
    frm.pack(fill="both", expand=True)

    ttk.Label(frm, text="💰 Finanzas Personales", font=("Segoe UI", 13, "bold")).pack(pady=(0, 8))
    ttk.Separator(frm, orient="horizontal").pack(fill="x", pady=8)

    # --- Ruta del archivo CSV ---
    data_path = Path(__file__).resolve().parents[2] / "data" / "sample.csv"

    # --- Totales ---
    total_ingresos = 0.0
    total_gastos = 0.0

    if data_path.exists():
        try:
            with open(data_path, newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    monto = float(row["Monto"])
                    if row["Tipo"].lower() == "ingreso":
                        total_ingresos += monto
                    else:
                        total_gastos += monto
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo leer el archivo:\n{e}")
    else:
        ttk.Label(frm, text="(Aún no hay datos registrados)", foreground="gray").pack(pady=4)

    saldo_total = total_ingresos - total_gastos

    # --- Mostrar resumen ---
    resumen = ttk.Frame(frm)
    resumen.pack(pady=12)

    ttk.Label(resumen, text=f"Ingresos: ${total_ingresos:,.2f}", foreground="green").grid(row=0, column=0, padx=16)
    ttk.Label(resumen, text=f"Gastos: ${total_gastos:,.2f}", foreground="red").grid(row=0, column=1, padx=16)
    ttk.Label(resumen, text=f"Saldo: ${saldo_total:,.2f}", font=("Segoe UI", 10, "bold")).grid(row=1, column=0, columnspan=2, pady=8)

    ttk.Separator(frm, orient="horizontal").pack(fill="x", pady=8)

    # --- Botones de navegación ---
    ttk.Button(frm, text="➕ Registrar Movimiento", command=lambda: open_win_form(parent)).pack(fill="x", pady=4)
    ttk.Button(frm, text="📋 Ver Tabla de Movimientos", command=lambda: open_win_table(parent)).pack(fill="x", pady=4)
    ttk.Button(frm, text="📑 Ver Listado", command=lambda: open_win_list(parent)).pack(fill="x", pady=4)

    ttk.Separator(frm, orient="horizontal").pack(fill="x", pady=8)
    ttk.Button(frm, text="Cerrar", command=win.destroy).pack(pady=6)

    win.transient(parent)
    win.grab_set()
    parent.wait_window(win)
