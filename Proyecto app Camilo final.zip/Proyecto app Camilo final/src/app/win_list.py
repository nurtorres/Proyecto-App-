import tkinter as tk
from tkinter import ttk, messagebox
import csv
from pathlib import Path
from datetime import datetime

def open_win_list(parent: tk.Tk):
    win = tk.Toplevel(parent)
    win.title("🎯 Meta de Ahorro Mensual")
    win.geometry("480x360")
    win.configure(bg="#f5f7fa")

    frm = ttk.Frame(win, padding=16)
    frm.pack(fill="both", expand=True)

    ttk.Label(frm, text="Progreso de Meta Financiera", font=("Segoe UI", 12, "bold")).pack(pady=(0, 8))
    ttk.Separator(frm, orient="horizontal").pack(fill="x", pady=6)

    # --- Campo para ingresar meta ---
    frm_meta = ttk.Frame(frm, padding=8)
    frm_meta.pack(fill="x", pady=6)

    ttk.Label(frm_meta, text="Meta de ahorro mensual ($):", font=("Segoe UI", 10)).pack(side="left", padx=(0, 6))
    ent_meta = ttk.Entry(frm_meta, width=12)
    ent_meta.pack(side="left")

    meta_valor = tk.DoubleVar(value=0.0)

    # --- Mostrar resultados ---
    lbl_mes = ttk.Label(frm, text="", font=("Segoe UI", 10, "bold"))
    lbl_mes.pack(pady=4)

    lbl_ahorro = ttk.Label(frm, text="Ahorro acumulado: $0.00", font=("Segoe UI", 10))
    lbl_ahorro.pack(pady=4)

    lbl_estado = ttk.Label(frm, text="", font=("Segoe UI", 10))
    lbl_estado.pack(pady=4)

    ttk.Separator(frm, orient="horizontal").pack(fill="x", pady=8)

    # --- Ruta de datos ---
    data_path = Path(__file__).resolve().parents[2] / "data" / "sample.csv"

    def calcular_progreso():
        """Calcula cuánto ha ahorrado el usuario este mes"""
        try:
            meta_valor.set(float(ent_meta.get()))
        except ValueError:
            messagebox.showerror("Error", "Por favor ingresa un número válido para la meta.")
            return

        if not data_path.exists():
            messagebox.showwarning("Sin datos", "Aún no hay movimientos registrados.")
            return

        ahora = datetime.now()
        mes_actual = ahora.strftime("%B %Y")
        total_ingresos = 0.0
        total_gastos = 0.0

        with open(data_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    fecha = datetime.strptime(row["Fecha"], "%Y-%m-%d")
                except Exception:
                    continue

                if fecha.month == ahora.month and fecha.year == ahora.year:
                    monto = float(row["Monto"])
                    if row["Tipo"].lower() == "ingreso":
                        total_ingresos += monto
                    else:
                        total_gastos += monto

        ahorro = total_ingresos - total_gastos
        lbl_mes.config(text=f"📅 Mes actual: {mes_actual}")
        lbl_ahorro.config(text=f"Ahorro acumulado: ${ahorro:,.2f}")

        meta = meta_valor.get()
        if meta <= 0:
            lbl_estado.config(text="Meta no establecida aún.", foreground="gray")
            return

        diferencia = meta - ahorro
        if diferencia <= 0:
            lbl_estado.config(text=f"🎉 ¡Meta alcanzada! Superaste por ${abs(diferencia):,.2f}", foreground="green")
        else:
            lbl_estado.config(text=f"Aún faltan ${diferencia:,.2f} para cumplir la meta.", foreground="red")

    # --- Botones ---
    frm_botones = ttk.Frame(frm, padding=8)
    frm_botones.pack(fill="x", side="bottom")

    ttk.Button(frm_botones, text="Calcular", command=calcular_progreso).pack(side="left", padx=6)
    ttk.Button(frm_botones, text="Cerrar", command=win.destroy).pack(side="right", padx=6)

    win.transient(parent)
    win.grab_set()
    parent.wait_window(win)
