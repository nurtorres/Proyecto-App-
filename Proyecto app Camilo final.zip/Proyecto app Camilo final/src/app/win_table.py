import tkinter as tk
from tkinter import ttk, messagebox
import csv
from pathlib import Path

def open_win_table(parent: tk.Tk):
    win = tk.Toplevel(parent)
    win.title("📋 Movimientos Registrados")
    win.geometry("660x600")
    win.configure(bg="#f5f7fa")

    frm = ttk.Frame(win, padding=16)
    frm.pack(fill="both", expand=True)

    ttk.Label(frm, text="Historial de Movimientos", font=("Segoe UI", 12, "bold")).pack(pady=(0, 8))
    ttk.Separator(frm, orient="horizontal").pack(fill="x", pady=6)

    data_path = Path(__file__).resolve().parents[2] / "data" / "sample.csv"

    # --- Configurar Treeview ---
    columnas = ("Tipo", "Monto", "Categoría", "Fecha", "Descripción")
    tabla = ttk.Treeview(frm, columns=columnas, show="headings", height=14)

    estilos = ttk.Style()
    estilos.configure("Treeview",
                      font=("Segoe UI", 9),
                      rowheight=24,
                      background="#ffffff",
                      fieldbackground="#ffffff")
    estilos.configure("Treeview.Heading",
                      font=("Segoe UI", 10, "bold"),
                      background="#0078d7",
                      foreground="white")
    estilos.map("Treeview.Heading",
                background=[("active", "#005fa3")])

    for col in columnas:
        ancho = 100 if col != "Descripción" else 200
        tabla.heading(col, text=col)
        tabla.column(col, anchor="center", width=ancho)
    tabla.pack(fill="both", expand=True, pady=(4, 0))

    scrollbar = ttk.Scrollbar(frm, orient="vertical", command=tabla.yview)
    tabla.configure(yscroll=scrollbar.set)
    scrollbar.pack(side="right", fill="y")

    # --- Función para cargar los datos ---
    def cargar_datos():
        for item in tabla.get_children():
            tabla.delete(item)
        if not data_path.exists():
            messagebox.showwarning("Aviso", "No hay datos registrados aún.")
            return

        with open(data_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                tabla.insert("", "end", values=(row["Tipo"], row["Monto"], row["Categoría"], row["Fecha"], row["Descripción"]))

    # --- Función para eliminar un registro ---
    def eliminar_registro():
        seleccion = tabla.selection()
        if not seleccion:
            messagebox.showwarning("Aviso", "Selecciona un movimiento para eliminar.")
            return

        respuesta = messagebox.askyesno("Confirmar eliminación", "¿Seguro que deseas eliminar este movimiento?")
        if not respuesta:
            return

        # Obtener valores del elemento seleccionado
        valores = tabla.item(seleccion[0], "values")

        # Leer todos los registros
        with open(data_path, newline="", encoding="utf-8") as f:
            registros = list(csv.DictReader(f))

        # Filtrar para eliminar el registro seleccionado (comparando todas las columnas)
        nuevos_registros = [
            r for r in registros
            if not (
                r["Tipo"] == valores[0] and
                r["Monto"] == valores[1] and
                r["Categoría"] == valores[2] and
                r["Fecha"] == valores[3] and
                r["Descripción"] == valores[4]
            )
        ]

        # Reescribir el CSV con los datos restantes
        with open(data_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["Tipo", "Monto", "Categoría", "Fecha", "Descripción"])
            writer.writeheader()
            writer.writerows(nuevos_registros)

        # Actualizar tabla visual
        cargar_datos()
        messagebox.showinfo("Eliminado", "El movimiento ha sido eliminado correctamente.")

    # --- Botones inferiores ---
    frm_botones = ttk.Frame(win, padding=10)
    frm_botones.pack(fill="x", side="bottom")

    ttk.Button(frm_botones, text="Actualizar", command=cargar_datos).pack(side="left", padx=6)
    ttk.Button(frm_botones, text="🗑 Eliminar", command=eliminar_registro).pack(side="left", padx=6)
    ttk.Button(frm_botones, text="Cerrar", command=win.destroy).pack(side="right", padx=6)

    cargar_datos()

    win.transient(parent)
    win.grab_set()
    parent.wait_window(win)
